/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/University/_Second Year/Computer Architectures/assesment/MyMicroProccessor/Lab_2/DataPaths - RegBankAlt/DataPath_D_TB.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1258338084_503743352(char *, char *, unsigned int , unsigned int );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_3676653908_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 5232U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(165, ng0);
    t2 = (t0 + 5896);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(166, ng0);
    t2 = (t0 + 4128U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 5040);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(167, ng0);
    t2 = (t0 + 5896);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(168, ng0);
    t2 = (t0 + 4128U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 5040);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_3676653908_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int64 t8;
    int t9;
    int t10;
    unsigned char t11;
    int t12;
    int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    char *t20;

LAB0:    t1 = (t0 + 5480U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(177, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 5288);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(179, ng0);
    t2 = (t0 + 5960);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(180, ng0);
    t2 = (t0 + 6024);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(181, ng0);
    t2 = (t0 + 4128U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t8 = (2 * t3);
    t2 = (t0 + 5288);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(184, ng0);
    t2 = (t0 + 14252);
    *((int *)t2) = 0;
    t4 = (t0 + 14256);
    *((int *)t4) = 8;
    t9 = 0;
    t10 = 8;

LAB12:    if (t9 <= t10)
        goto LAB13;

LAB15:    xsi_set_current_line(212, ng0);

LAB27:    *((char **)t1) = &&LAB28;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB13:    xsi_set_current_line(187, ng0);

LAB18:    t5 = (t0 + 5800);
    *((int *)t5) = 1;
    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB14:    t2 = (t0 + 14252);
    t9 = *((int *)t2);
    t4 = (t0 + 14256);
    t10 = *((int *)t4);
    if (t9 == t10)
        goto LAB15;

LAB24:    t12 = (t9 + 1);
    t9 = t12;
    t5 = (t0 + 14252);
    *((int *)t5) = t9;
    goto LAB12;

LAB16:    t7 = (t0 + 5800);
    *((int *)t7) = 0;
    xsi_set_current_line(190, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 0U);
    t5 = (t4 + t17);
    t6 = (t0 + 6088);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 5U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(191, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 5U);
    t5 = (t4 + t17);
    t6 = (t0 + 6152);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 5U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(193, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 10U);
    t5 = (t4 + t17);
    t11 = *((unsigned char *)t5);
    t6 = (t0 + 6216);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t11;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(194, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 11U);
    t5 = (t4 + t17);
    t6 = (t0 + 6280);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 5U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(196, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 16U);
    t5 = (t4 + t17);
    t6 = (t0 + 6344);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 16U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(197, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 32U);
    t5 = (t4 + t17);
    t6 = (t0 + 6408);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 16U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(198, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 48U);
    t5 = (t4 + t17);
    t6 = (t0 + 6472);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 16U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(200, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 64U);
    t5 = (t4 + t17);
    t6 = (t0 + 6536);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 8U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(201, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 72U);
    t5 = (t4 + t17);
    t6 = (t0 + 6600);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 4U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(202, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 76U);
    t5 = (t4 + t17);
    t6 = (t0 + 6664);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    memcpy(t20, t5, 4U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(204, ng0);
    t2 = (t0 + 4248U);
    t4 = *((char **)t2);
    t2 = (t0 + 14252);
    t12 = *((int *)t2);
    t13 = (t12 - 0);
    t14 = (t13 * 1);
    t15 = (88U * t14);
    t16 = (0 + t15);
    t17 = (t16 + 80U);
    t5 = (t4 + t17);
    t11 = *((unsigned char *)t5);
    t6 = (t0 + 6728);
    t7 = (t6 + 56U);
    t18 = *((char **)t7);
    t19 = (t18 + 56U);
    t20 = *((char **)t19);
    *((unsigned char *)t20) = t11;
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(207, ng0);

LAB22:    t2 = (t0 + 5816);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB17:    t6 = (t0 + 992U);
    t11 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t6, 0U, 0U);
    if (t11 == 1)
        goto LAB16;
    else
        goto LAB18;

LAB19:    goto LAB17;

LAB20:    t5 = (t0 + 5816);
    *((int *)t5) = 0;
    goto LAB14;

LAB21:    t4 = (t0 + 992U);
    t11 = ieee_p_2592010699_sub_1258338084_503743352(IEEE_P_2592010699, t4, 0U, 0U);
    if (t11 == 1)
        goto LAB20;
    else
        goto LAB22;

LAB23:    goto LAB21;

LAB25:    goto LAB2;

LAB26:    goto LAB25;

LAB28:    goto LAB26;

}


extern void work_a_3676653908_2372691052_init()
{
	static char *pe[] = {(void *)work_a_3676653908_2372691052_p_0,(void *)work_a_3676653908_2372691052_p_1};
	xsi_register_didat("work_a_3676653908_2372691052", "isim/DataPath_D_TB_isim_beh.exe.sim/work/a_3676653908_2372691052.didat");
	xsi_register_executes(pe);
}
