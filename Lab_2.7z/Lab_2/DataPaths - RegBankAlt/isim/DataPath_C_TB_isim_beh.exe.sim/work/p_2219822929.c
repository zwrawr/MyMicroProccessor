/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xa0883be4 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

int ieee_p_1242562249_sub_1657552908_1035706684(char *, char *, char *);
int ieee_p_1242562249_sub_2271993008_1035706684(char *, char *, char *);


char *work_p_2219822929_sub_1076499427_1544464631(char *t1, char *t2, unsigned char t3)
{
    char t4[152];
    char t5[8];
    char t6[16];
    char t28[16];
    char t38[16];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    int t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    unsigned int t35;
    int t36;
    unsigned char t37;
    int t39;
    int t40;
    int t41;
    int t42;
    int t43;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 1;
    t8 = (t7 + 4U);
    *((int *)t8) = 3;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (3 - 1);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t4 + 4U);
    t11 = ((STD_STANDARD) + 1008);
    t12 = (t8 + 88U);
    *((char **)t12) = t11;
    t13 = xsi_get_memory(3U);
    t14 = (t8 + 56U);
    *((char **)t14) = t13;
    xsi_type_set_default_value(t11, t13, t6);
    t15 = (t8 + 64U);
    *((char **)t15) = t6;
    t16 = (t8 + 80U);
    *((unsigned int *)t16) = 3U;
    t17 = (t8 + 136U);
    *((char **)t17) = t13;
    t18 = (t8 + 124U);
    *((int *)t18) = 0;
    t19 = (t8 + 128U);
    t20 = (t6 + 12U);
    t10 = *((unsigned int *)t20);
    t21 = (t10 - 1);
    *((int *)t19) = t21;
    t22 = (t8 + 120U);
    t24 = (3U > 2147483644);
    if (t24 == 1)
        goto LAB2;

LAB3:    t25 = (3U + 3);
    t26 = (t25 / 16);
    t23 = t26;

LAB4:    *((unsigned int *)t22) = t23;
    t27 = (t5 + 4U);
    *((unsigned char *)t27) = t3;
    t29 = ((IEEE_P_2592010699) + 3224);
    t30 = xsi_char_to_mem(t3);
    t31 = xsi_string_variable_get_image(t28, t29, t30);
    t32 = (t8 + 56U);
    t33 = *((char **)t32);
    t32 = (t33 + 0);
    t34 = (t28 + 12U);
    t35 = *((unsigned int *)t34);
    memcpy(t32, t31, t35);
    t7 = (t1 + 3608);
    t12 = (t8 + 56U);
    t13 = *((char **)t12);
    t12 = (t6 + 0U);
    t9 = *((int *)t12);
    t14 = (t6 + 8U);
    t21 = *((int *)t14);
    t36 = (2 - t9);
    t10 = (t36 * t21);
    t23 = (1U * t10);
    t24 = (0 + t23);
    t15 = (t13 + t24);
    t37 = *((unsigned char *)t15);
    t17 = ((STD_STANDARD) + 1008);
    t18 = (t38 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = 1;
    t19 = (t18 + 4U);
    *((int *)t19) = 0;
    t19 = (t18 + 8U);
    *((int *)t19) = 1;
    t39 = (0 - 1);
    t25 = (t39 * 1);
    t25 = (t25 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t25;
    t16 = xsi_base_array_concat(t16, t28, t17, (char)97, t7, t38, (char)99, t37, (char)101);
    t25 = (0U + 1U);
    t0 = xsi_get_transient_memory(t25);
    memcpy(t0, t16, t25);
    t19 = (t28 + 0U);
    t40 = *((int *)t19);
    t20 = (t28 + 4U);
    t41 = *((int *)t20);
    t22 = (t28 + 8U);
    t42 = *((int *)t22);
    t29 = (t2 + 0U);
    t30 = (t29 + 0U);
    *((int *)t30) = t40;
    t30 = (t29 + 4U);
    *((int *)t30) = t41;
    t30 = (t29 + 8U);
    *((int *)t30) = t42;
    t43 = (t41 - t40);
    t26 = (t43 * t42);
    t26 = (t26 + 1);
    t30 = (t29 + 12U);
    *((unsigned int *)t30) = t26;

LAB1:    t7 = (t8 + 80);
    t9 = *((int *)t7);
    t11 = (t8 + 136U);
    t12 = *((char **)t11);
    xsi_put_memory(t9, t12);
    return t0;
LAB2:    t23 = 2147483647;
    goto LAB4;

LAB5:;
}

char *work_p_2219822929_sub_1026661507_1544464631(char *t1, char *t2, char *t3, char *t4)
{
    char t5[296];
    char t6[24];
    char t7[16];
    char t14[16];
    char t37[16];
    char t73[16];
    char *t0;
    char *t8;
    unsigned int t9;
    char *t10;
    char *t11;
    int t12;
    unsigned int t13;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    unsigned int t34;
    int t35;
    unsigned int t36;
    char *t38;
    unsigned int t39;
    char *t40;
    char *t41;
    int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    char *t51;
    char *t52;
    char *t53;
    int t54;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    char *t60;
    unsigned char t61;
    char *t62;
    char *t63;
    int t64;
    char *t65;
    int t66;
    char *t67;
    int t68;
    int t69;
    int t70;
    int t71;
    int t72;
    char *t74;
    char *t75;
    int t76;
    char *t77;
    int t78;
    int t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    char *t83;
    unsigned char t84;
    char *t85;
    char *t86;
    char *t87;
    char *t88;
    unsigned int t89;

LAB0:    t8 = (t4 + 12U);
    t9 = *((unsigned int *)t8);
    t10 = (t7 + 0U);
    t11 = (t10 + 0U);
    *((int *)t11) = 1;
    t11 = (t10 + 4U);
    *((unsigned int *)t11) = t9;
    t11 = (t10 + 8U);
    *((int *)t11) = 1;
    t12 = (t9 - 1);
    t13 = (t12 * 1);
    t13 = (t13 + 1);
    t11 = (t10 + 12U);
    *((unsigned int *)t11) = t13;
    t11 = (t14 + 0U);
    t15 = (t11 + 0U);
    *((int *)t15) = 1;
    t15 = (t11 + 4U);
    *((int *)t15) = 1;
    t15 = (t11 + 8U);
    *((int *)t15) = 1;
    t16 = (1 - 1);
    t13 = (t16 * 1);
    t13 = (t13 + 1);
    t15 = (t11 + 12U);
    *((unsigned int *)t15) = t13;
    t15 = (t5 + 4U);
    t17 = ((STD_STANDARD) + 1008);
    t18 = (t15 + 88U);
    *((char **)t18) = t17;
    t19 = xsi_get_memory(1U);
    t20 = (t15 + 56U);
    *((char **)t20) = t19;
    xsi_type_set_default_value(t17, t19, t14);
    t21 = (t15 + 64U);
    *((char **)t21) = t14;
    t22 = (t15 + 80U);
    *((unsigned int *)t22) = 1U;
    t23 = (t15 + 136U);
    *((char **)t23) = t19;
    t24 = (t15 + 124U);
    *((int *)t24) = 0;
    t25 = (t15 + 128U);
    t26 = (t14 + 12U);
    t13 = *((unsigned int *)t26);
    t27 = (t13 - 1);
    *((int *)t25) = t27;
    t28 = (t15 + 120U);
    t30 = (1U > 2147483644);
    if (t30 == 1)
        goto LAB2;

LAB3:    t31 = (1U + 3);
    t32 = (t31 / 16);
    t29 = t32;

LAB4:    *((unsigned int *)t28) = t29;
    t33 = (t4 + 12U);
    t34 = *((unsigned int *)t33);
    t35 = (t34 - 1);
    t36 = (t35 * 1);
    t36 = (t36 + 1);
    t36 = (t36 * 1U);
    t38 = (t4 + 12U);
    t39 = *((unsigned int *)t38);
    t40 = (t37 + 0U);
    t41 = (t40 + 0U);
    *((int *)t41) = 1;
    t41 = (t40 + 4U);
    *((unsigned int *)t41) = t39;
    t41 = (t40 + 8U);
    *((int *)t41) = 1;
    t42 = (t39 - 1);
    t43 = (t42 * 1);
    t43 = (t43 + 1);
    t41 = (t40 + 12U);
    *((unsigned int *)t41) = t43;
    t41 = (t5 + 148U);
    t44 = ((STD_STANDARD) + 1008);
    t45 = (t41 + 88U);
    *((char **)t45) = t44;
    t46 = xsi_get_memory(t36);
    t47 = (t41 + 56U);
    *((char **)t47) = t46;
    xsi_type_set_default_value(t44, t46, t37);
    t48 = (t41 + 64U);
    *((char **)t48) = t37;
    t49 = (t41 + 80U);
    *((unsigned int *)t49) = t36;
    t50 = (t41 + 136U);
    *((char **)t50) = t46;
    t51 = (t41 + 124U);
    *((int *)t51) = 0;
    t52 = (t41 + 128U);
    t53 = (t37 + 12U);
    t43 = *((unsigned int *)t53);
    t54 = (t43 - 1);
    *((int *)t52) = t54;
    t55 = (t41 + 120U);
    t57 = (t36 > 2147483644);
    if (t57 == 1)
        goto LAB5;

LAB6:    t58 = (t36 + 3);
    t59 = (t58 / 16);
    t56 = t59;

LAB7:    *((unsigned int *)t55) = t56;
    t60 = (t6 + 4U);
    t61 = (t3 != 0);
    if (t61 == 1)
        goto LAB9;

LAB8:    t62 = (t6 + 12U);
    *((char **)t62) = t4;
    t63 = (t7 + 8U);
    t64 = *((int *)t63);
    t65 = (t7 + 4U);
    t66 = *((int *)t65);
    t67 = (t7 + 0U);
    t68 = *((int *)t67);
    t69 = t68;
    t70 = t66;

LAB10:    t71 = (t70 * t64);
    t72 = (t69 * t64);
    if (t72 <= t71)
        goto LAB11;

LAB13:    t8 = (t41 + 56U);
    t10 = *((char **)t8);
    t8 = (t37 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t10, t9);
    t11 = (t37 + 0U);
    t12 = *((int *)t11);
    t17 = (t37 + 4U);
    t16 = *((int *)t17);
    t18 = (t37 + 8U);
    t27 = *((int *)t18);
    t19 = (t2 + 0U);
    t20 = (t19 + 0U);
    *((int *)t20) = t12;
    t20 = (t19 + 4U);
    *((int *)t20) = t16;
    t20 = (t19 + 8U);
    *((int *)t20) = t27;
    t35 = (t16 - t12);
    t13 = (t35 * t27);
    t13 = (t13 + 1);
    t20 = (t19 + 12U);
    *((unsigned int *)t20) = t13;

LAB1:    t8 = (t41 + 80);
    t12 = *((int *)t8);
    t10 = (t41 + 136U);
    t11 = *((char **)t10);
    xsi_put_memory(t12, t11);
    t17 = (t15 + 80);
    t16 = *((int *)t17);
    t18 = (t15 + 136U);
    t19 = *((char **)t18);
    xsi_put_memory(t16, t19);
    return t0;
LAB2:    t29 = 2147483647;
    goto LAB4;

LAB5:    t56 = 2147483647;
    goto LAB7;

LAB9:    *((char **)t60) = t3;
    goto LAB8;

LAB11:    t74 = (t3 + 0);
    t75 = (t7 + 0U);
    t76 = *((int *)t75);
    t77 = (t7 + 8U);
    t78 = *((int *)t77);
    t79 = (t69 - t76);
    t80 = (t79 * t78);
    t81 = (1U * t80);
    t82 = (0 + t81);
    t83 = (t74 + t82);
    t84 = *((unsigned char *)t83);
    t85 = work_p_2219822929_sub_1076499427_1544464631(t1, t73, t84);
    t86 = (t15 + 56U);
    t87 = *((char **)t86);
    t86 = (t87 + 0);
    t88 = (t73 + 12U);
    t89 = *((unsigned int *)t88);
    t89 = (t89 * 1U);
    memcpy(t86, t85, t89);
    t8 = (t15 + 56U);
    t10 = *((char **)t8);
    t8 = (t14 + 0U);
    t12 = *((int *)t8);
    t11 = (t14 + 8U);
    t16 = *((int *)t11);
    t27 = (1 - t12);
    t9 = (t27 * t16);
    t13 = (1U * t9);
    t29 = (0 + t13);
    t17 = (t10 + t29);
    t61 = *((unsigned char *)t17);
    t18 = (t41 + 56U);
    t19 = *((char **)t18);
    t18 = (t37 + 0U);
    t35 = *((int *)t18);
    t20 = (t37 + 8U);
    t42 = *((int *)t20);
    t54 = (t69 - t35);
    t30 = (t54 * t42);
    t21 = (t37 + 4U);
    t66 = *((int *)t21);
    xsi_vhdl_check_range_of_index(t35, t66, t42, t69);
    t31 = (1U * t30);
    t32 = (0 + t31);
    t22 = (t19 + t32);
    *((unsigned char *)t22) = t61;

LAB12:    if (t69 == t70)
        goto LAB13;

LAB14:    t12 = (t69 + t64);
    t69 = t12;
    goto LAB10;

LAB15:;
}

char *work_p_2219822929_sub_2632965548_1544464631(char *t1, char *t2, char *t3, char *t4)
{
    char t6[24];
    char t10[16];
    char *t0;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t11;
    int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    char *t17;
    int t18;
    char *t19;
    int t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    unsigned int t26;

LAB0:    t7 = (t6 + 4U);
    t8 = (t3 != 0);
    if (t8 == 1)
        goto LAB3;

LAB2:    t9 = (t6 + 12U);
    *((char **)t9) = t4;
    t11 = ((STD_STANDARD) + 384);
    t12 = ieee_p_1242562249_sub_2271993008_1035706684(IEEE_P_1242562249, t3, t4);
    t13 = xsi_int_to_mem(t12);
    t14 = xsi_string_variable_get_image(t10, t11, t13);
    t15 = (t10 + 12U);
    t16 = *((unsigned int *)t15);
    t0 = xsi_get_transient_memory(t16);
    memcpy(t0, t14, t16);
    t17 = (t10 + 0U);
    t18 = *((int *)t17);
    t19 = (t10 + 4U);
    t20 = *((int *)t19);
    t21 = (t10 + 8U);
    t22 = *((int *)t21);
    t23 = (t2 + 0U);
    t24 = (t23 + 0U);
    *((int *)t24) = t18;
    t24 = (t23 + 4U);
    *((int *)t24) = t20;
    t24 = (t23 + 8U);
    *((int *)t24) = t22;
    t25 = (t20 - t18);
    t26 = (t25 * t22);
    t26 = (t26 + 1);
    t24 = (t23 + 12U);
    *((unsigned int *)t24) = t26;

LAB1:    return t0;
LAB3:    *((char **)t7) = t3;
    goto LAB2;

LAB4:;
}

char *work_p_2219822929_sub_2246623150_1544464631(char *t1, char *t2, char *t3, char *t4)
{
    char t6[24];
    char t10[16];
    char *t0;
    char *t7;
    unsigned char t8;
    char *t9;
    char *t11;
    int t12;
    char *t13;
    char *t14;
    char *t15;
    unsigned int t16;
    char *t17;
    int t18;
    char *t19;
    int t20;
    char *t21;
    int t22;
    char *t23;
    char *t24;
    int t25;
    unsigned int t26;

LAB0:    t7 = (t6 + 4U);
    t8 = (t3 != 0);
    if (t8 == 1)
        goto LAB3;

LAB2:    t9 = (t6 + 12U);
    *((char **)t9) = t4;
    t11 = ((STD_STANDARD) + 384);
    t12 = ieee_p_1242562249_sub_1657552908_1035706684(IEEE_P_1242562249, t3, t4);
    t13 = xsi_int_to_mem(t12);
    t14 = xsi_string_variable_get_image(t10, t11, t13);
    t15 = (t10 + 12U);
    t16 = *((unsigned int *)t15);
    t0 = xsi_get_transient_memory(t16);
    memcpy(t0, t14, t16);
    t17 = (t10 + 0U);
    t18 = *((int *)t17);
    t19 = (t10 + 4U);
    t20 = *((int *)t19);
    t21 = (t10 + 8U);
    t22 = *((int *)t21);
    t23 = (t2 + 0U);
    t24 = (t23 + 0U);
    *((int *)t24) = t18;
    t24 = (t23 + 4U);
    *((int *)t24) = t20;
    t24 = (t23 + 8U);
    *((int *)t24) = t22;
    t25 = (t20 - t18);
    t26 = (t25 * t22);
    t26 = (t26 + 1);
    t24 = (t23 + 12U);
    *((unsigned int *)t24) = t26;

LAB1:    return t0;
LAB3:    *((char **)t7) = t3;
    goto LAB2;

LAB4:;
}


extern void work_p_2219822929_init()
{
	static char *se[] = {(void *)work_p_2219822929_sub_1076499427_1544464631,(void *)work_p_2219822929_sub_1026661507_1544464631,(void *)work_p_2219822929_sub_2632965548_1544464631,(void *)work_p_2219822929_sub_2246623150_1544464631};
	xsi_register_didat("work_p_2219822929", "isim/DataPath_C_TB_isim_beh.exe.sim/work/p_2219822929.didat");
	xsi_register_subprogram_executes(se);
}
